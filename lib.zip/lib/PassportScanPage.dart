import 'package:flutter/material.dart';


class PassportScanPage extends StatefulWidget {
  @override
  _PassportScanPageState createState() => _PassportScanPageState();
}

class _PassportScanPageState extends State<PassportScanPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  bool isScanning = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2), // Animation duration
    );

    // Scale animation
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      ),
    );

    // Fade animation
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeIn,
      ),
    );

    _controller.forward(); // Start the animation
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 40),
            Text(
              'Passport Scan',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Using your phone’s back camera, scan your passport.',
              style: TextStyle(
                fontSize: 16,

              ),
            ),

            // Animated image
            Center(
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: Image.asset(
                    'assets/passport_scan.png', // Replace with your actual image path
                    height: 250,
                    width: 250,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            SizedBox(height: 50),
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'FOR THE BEST RESULT',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    '• Hold the document straight and steady.',
                    style: TextStyle(
                    fontSize: 16,
                  ),
                 ),
                  Text(
                      '• Take in a well-lit place without direct light or shadows on your face.',
                    style: TextStyle(
                    fontSize: 16,
                  ),),
                  Text('• Ensure there is no glare or shadows on the passport.',
                    style: TextStyle(
                      fontSize: 16,
                    ),),
                ],
              ),
            ),
            SizedBox(height: 50),
            Center(
              child: GestureDetector(
                onTap: isScanning
                    ? null
                    : () async {
                  setState(() {
                    isScanning = true;
                  });
                  await Future.delayed(Duration(seconds: 2)); // Simulate scanning
                  setState(() {
                    isScanning = false;
                  });

                  // Show success message after scanning
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Passport scanned successfully!'),
                    ),
                  );

                },
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.green[900], // Green background color
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: isScanning
                      ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white, // Progress indicator color
                      strokeWidth: 2,
                    ),
                  )
                      : Text(
                    'Scan Passport',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),

            ),
          ],
        ),
      ),
    );
  }
}